# -*- coding: utf-8 -*-
"""
Created on Fri Dec  6 08:13:00 2019

@author: kaw
"""

import pyaudio
import wave
import sys

CHUNK_SIZE = 1024

def play_wav(wav_filename, chunk_size=CHUNK_SIZE):
    ''' Toca no sistema de som (auto-falante) o arquivo WAV
    denominado wav_filename. '''
    try:
        print('\nTocando o arquivo "' + wav_filename + '"...')
        wf = wave.open(wav_filename, 'rb')
    except IOError as ioe:
        sys.stderr.write('IOError no arquivo ' + wav_filename + '\n' + \
        str(ioe) + '. Pulando...\n')
        return
    except EOFError as eofe:
        sys.stderr.write('EOFError no arquivo' + wav_filename + '\n' + \
        str(eofe) + '. Pulando...\n')
        return
    p = pyaudio.PyAudio()                  # Instanciando PyAudio (objeto)
    # Abre o fluxo de bits (auto-falante)
    stream = p.open(format = p.get_format_from_width(wf.getsampwidth()),
             channels = wf.getnchannels(), rate = wf.getframerate(), output=True)
    data = wf.readframes(chunk_size)       # lendo um pedaço do arq. WAV
    while len(data) > 0:
        stream.write(data)                 # grava dados do arq. WAV no fluxo
        data = wf.readframes(chunk_size)   # lendo outro pedaço do arq. WAV    
    stream.stop_stream()                   # pára o fluxo de bits (auto-falante)
    stream.close()
    p.terminate()                          # Fecha PyAudio

play_wav('E:\\mdp\\Curso\\disc.s\\pds\\_Lab\\_Roteiros\\_ jupyter\\08-Espectrograma\\sos-morse-code.wav')